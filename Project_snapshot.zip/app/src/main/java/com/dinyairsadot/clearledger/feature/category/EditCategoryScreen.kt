@file:OptIn(ExperimentalFoundationApi::class)

package com.dinyairsadot.clearledger.feature.category

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.TopAppBar
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.dinyairsadot.clearledger.core.ui.SwipeDismissSnackbarHost
import com.dinyairsadot.clearledger.core.ui.categoryTopAppBarColors
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.dinyairsadot.clearledger.core.domain.Category
import com.dinyairsadot.clearledger.feature.category.CategoryListViewModel
import com.dinyairsadot.clearledger.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private data class EditableCategorySnapshot(
    val name: String,
    val colorHex: String,
    val description: String,
    val customFieldTitles: List<String>
)

private fun editableSnapshot(
    name: String,
    colorHex: String,
    description: String,
    customFieldTitles: List<String>,
    pendingNewFieldName: String = ""
): EditableCategorySnapshot {
    val resolved = resolveCustomFieldTitlesForSave(
        customFieldTitles = customFieldTitles,
        pendingNewFieldName = pendingNewFieldName,
        onDuplicatePendingField = {}
    ) ?: customFieldTitles.map { it.trim() }.filter { it.isNotBlank() }
    return EditableCategorySnapshot(
        name = name.trim(),
        colorHex = colorHex.trim(),
        description = description.trim(),
        customFieldTitles = resolved
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditCategoryScreen(
    categoryId: Long,
    initialName: String,
    initialColorHex: String,
    categoryColorHex: String?,
    initialDescription: String?,
    initialCustomFieldTitles: List<String>,
    otherNamesLower: Set<String>,
    onNavigateBack: () -> Unit,
    onSaveCategory: (
        name: String,
        colorHex: String,
        description: String,
        customFieldTitles: List<String>
    ) -> Unit,
    viewModel: CategoryListViewModel
) {
    var name by rememberSaveable { mutableStateOf(initialName) }
    var colorHex by rememberSaveable { mutableStateOf(initialColorHex) }
    var description by rememberSaveable { mutableStateOf(initialDescription.orEmpty()) }

    var customFieldTitles by rememberSaveable { mutableStateOf(initialCustomFieldTitles) }
    var pendingRemoveFieldIndex by rememberSaveable { mutableStateOf<Int?>(null) }
    var hasFieldData by rememberSaveable { mutableStateOf(false) }
    
    var showPendingNewFieldInput by rememberSaveable { mutableStateOf(false) }
    var newFieldName by rememberSaveable { mutableStateOf("") }
    var selectedTopicId by rememberSaveable { mutableStateOf<String?>(null) }
    var showDiscardChangesDialog by rememberSaveable { mutableStateOf(false) }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val nameScrollAnchor = remember { BringIntoViewRequester() }
    val colorSectionScrollAnchor = remember { BringIntoViewRequester() }
    var nameError by remember { mutableStateOf<String?>(null) }
    var colorError by remember { mutableStateOf<String?>(null) }
    var fieldExistsError by remember { mutableStateOf<String?>(null) }

    // Check if invoices have data in the field when removal is requested
    LaunchedEffect(pendingRemoveFieldIndex) {
        if (pendingRemoveFieldIndex != null) {
            hasFieldData = viewModel.hasInvoicesWithFieldData(categoryId, pendingRemoveFieldIndex!!)
        }
    }

    fun removeCustomFieldAt(index: Int) {
        val newList = customFieldTitles.toMutableList()
        newList.removeAt(index)
        customFieldTitles = newList
    }
    
    fun onShowPendingNewFieldClick() {
        if (showPendingNewFieldInput) {
            val trimmed = newFieldName.trim()
            if (trimmed.isNotBlank()) {
                val committed = customFieldTitles.map { it.trim() }.filter { it.isNotBlank() }
                if (committed.any { it.equals(trimmed, ignoreCase = true) }) {
                    fieldExistsError = context.getString(R.string.field_already_exists)
                    return
                }
                if (committed.size >= Category.MAX_CUSTOM_FIELDS) {
                    showPendingNewFieldInput = false
                    newFieldName = ""
                    return
                }
                customFieldTitles = committed + trimmed
                newFieldName = ""
                fieldExistsError = null
            }
        }
        showPendingNewFieldInput = customFieldTitles.size < Category.MAX_CUSTOM_FIELDS
    }

    fun addFieldFromCatalog(fieldName: String) {
        val trimmed = fieldName.trim()
        if (trimmed.isBlank()) return
        val committed = customFieldTitles.map { it.trim() }.filter { it.isNotBlank() }
        if (committed.any { it.equals(trimmed, ignoreCase = true) }) {
            fieldExistsError = context.getString(R.string.field_already_exists)
            return
        }
        if (committed.size >= Category.MAX_CUSTOM_FIELDS) {
            return
        }
        customFieldTitles = committed + trimmed
        fieldExistsError = null
        if (customFieldTitles.size >= Category.MAX_CUSTOM_FIELDS) {
            showPendingNewFieldInput = false
            newFieldName = ""
        }
    }

    fun onSaveClicked() {
        var hasError = false

        if (name.isBlank()) {
            nameError = context.getString(R.string.name_required)
            hasError = true
        } else if (otherNamesLower.contains(name.trim().lowercase())) {
            nameError = context.getString(R.string.name_must_be_unique)
            hasError = true
        } else {
            nameError = null
        }

        if (colorHex.isNotBlank()) {
            val regex = Regex("^#[0-9A-Fa-f]{6}$")
            if (!regex.matches(colorHex.trim())) {
                colorError = context.getString(R.string.color_must_be_rrggbb_format)
                hasError = true
            } else {
                colorError = null
            }
        } else {
            colorError = null
        }

        if (hasError) {
            coroutineScope.launch {
                delay(50)
                if (nameError != null) {
                    nameScrollAnchor.bringIntoView()
                } else if (colorError != null) {
                    colorSectionScrollAnchor.bringIntoView()
                }
                snackbarHostState.showSnackbar(
                    message = context.getString(R.string.please_fix_highlighted_fields),
                    withDismissAction = true
                )
            }
            return
        }

        val trimmedTitles = resolveCustomFieldTitlesForSave(
            customFieldTitles = customFieldTitles,
            pendingNewFieldName = newFieldName,
            onDuplicatePendingField = {
                fieldExistsError = context.getString(R.string.field_already_exists)
                showPendingNewFieldInput = true
            }
        ) ?: return

        onSaveCategory(
            name.trim(),
            colorHex.trim(),
            description.trim(),
            trimmedTitles
        )
        onNavigateBack()
    }

    val originalSnapshot = remember(
        initialName,
        initialColorHex,
        initialDescription,
        initialCustomFieldTitles
    ) {
        editableSnapshot(
            name = initialName,
            colorHex = initialColorHex,
            description = initialDescription.orEmpty(),
            customFieldTitles = initialCustomFieldTitles
        )
    }
    val hasUnsavedChanges = editableSnapshot(
        name = name,
        colorHex = colorHex,
        description = description,
        customFieldTitles = customFieldTitles,
        pendingNewFieldName = newFieldName
    ) != originalSnapshot

    fun onBackRequested() {
        if (hasUnsavedChanges) {
            showDiscardChangesDialog = true
        } else {
            onNavigateBack()
        }
    }

    BackHandler {
        onBackRequested()
    }

    val formState = CategoryFormState(
        name = name,
        nameError = nameError,
        colorHex = colorHex,
        colorError = colorError,
        description = description,
        customFieldTitles = customFieldTitles,
        showPendingNewFieldInput = showPendingNewFieldInput,
        newFieldName = newFieldName,
        selectedTopicId = selectedTopicId,
        fieldExistsError = fieldExistsError
    )

    val formCallbacks = CategoryFormCallbacks(
        onNameChange = { newName ->
            name = newName
            if (nameError != null) nameError = null
        },
        onColorHexChange = { newColor ->
            colorHex = newColor
            if (colorError != null) colorError = null
        },
        onDescriptionChange = { newDesc ->
            description = newDesc
        },
        onSaveClick = { onSaveClicked() },
        onCustomFieldTitleChange = { index, value ->
            val newList = customFieldTitles.toMutableList()
            if (index < newList.size) {
                newList[index] = value
            } else {
                newList.add(value)
            }
            customFieldTitles = newList
        },
        onShowPendingNewFieldClick = { onShowPendingNewFieldClick() },
        onRequestRemoveCustomField = { index ->
            pendingRemoveFieldIndex = index
        },
        onNewFieldNameChange = { newName ->
            newFieldName = newName
            if (fieldExistsError != null) fieldExistsError = null
        },
        onTopicSelected = { topicId ->
            selectedTopicId = topicId
        },
        onAddFieldFromCatalog = { fieldName ->
            addFieldFromCatalog(fieldName)
        }
    )

    Scaffold(
        contentWindowInsets = WindowInsets.systemBars,
        snackbarHost = { SwipeDismissSnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.edit_category_title)) },
                colors = categoryTopAppBarColors(colorHex.takeIf { it.isNotBlank() }),
                navigationIcon = {
                    IconButton(onClick = ::onBackRequested) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                actions = {
                    TextButton(onClick = ::onSaveClicked) {
                        Text(text = stringResource(R.string.save))
                    }
                }
            )
        }
    ) { innerPadding ->
        if (showDiscardChangesDialog) {
            AlertDialog(
                onDismissRequest = { showDiscardChangesDialog = false },
                title = { Text(stringResource(R.string.discard_changes_title)) },
                text = { Text(stringResource(R.string.discard_changes_message)) },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showDiscardChangesDialog = false
                            onNavigateBack()
                        }
                    ) {
                        Text(stringResource(R.string.discard))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDiscardChangesDialog = false }) {
                        Text(stringResource(R.string.keep_editing))
                    }
                }
            )
        }
        if (pendingRemoveFieldIndex != null) {
            val fieldIndex = pendingRemoveFieldIndex!!
            val fieldTitle = customFieldTitles.getOrNull(fieldIndex)?.takeIf { it.isNotBlank() }
                ?: context.getString(R.string.field_number, fieldIndex + 1)
            
            AlertDialog(
                onDismissRequest = { pendingRemoveFieldIndex = null },
                title = { Text(stringResource(R.string.remove_custom_field)) },
                text = {
                    Text(context.getString(R.string.remove_custom_field_confirmation, fieldTitle))
                },
                confirmButton = {
                    TextButton(onClick = {
                        removeCustomFieldAt(fieldIndex)
                        pendingRemoveFieldIndex = null
                    }) {
                        Text(stringResource(R.string.remove))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingRemoveFieldIndex = null }) {
                        Text(stringResource(R.string.cancel))
                    }
                }
            )
        }
        CategoryForm(
            state = formState,
            callbacks = formCallbacks,
            saveButtonLabel = stringResource(R.string.save_changes),
            nameScrollAnchor = nameScrollAnchor,
            colorSectionScrollAnchor = colorSectionScrollAnchor,
            modifier = Modifier
                .padding(innerPadding)
                .imePadding()
        )
    }
}